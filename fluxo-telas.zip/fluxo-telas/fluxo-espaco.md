# Fluxo de Telas — Espaços

**Ator:** Gestor (Administração)

---

## 1. Gestor cadastra um novo espaço

**Tela:** Administração → Espaços → modal "Cadastrar espaço"

![Cadastrar espaço](espaco-01-cadastrar.png)

O gestor clica em **+ Novo espaço** e preenche o modal com:

- **Nome** (obrigatório) — ex.: `Espaço Cultural`
- **Capacidade máxima** (obrigatório) — número de lugares estipulado pelos bombeiros (ex.: `100`)
- **Rider técnico** (opcional) — itens separados por vírgula que descrevem os recursos técnicos disponíveis no espaço (ex.: `Microfone, Caixa de Som`)

Ao clicar em **Cadastrar**, o espaço é criado com status **ATIVO** e fica disponível para receber eventos.

---

## 2. Gestor atualiza a capacidade de um espaço

**Tela:** Administração → Espaços → modal "Atualizar capacidade"

![Atualizar capacidade](espaco-02-atualizar-capacidade.png)

O gestor aciona a ação de atualizar capacidade para um espaço ativo. O modal exibe:

- **Espaço** — dropdown com o espaço selecionado (ex.: `Espaço Cultural · 100 lugares · ATIVO`)
- **Nova capacidade** (obrigatório) — novo valor numérico (ex.: `120`)
- **Ingressos vendidos (futuros)** — campo informativo que exibe quantos ingressos já foram vendidos para eventos futuros neste espaço (ex.: `0`)

> A nova capacidade não pode ser menor que o número de ingressos já vendidos para eventos futuros.

Ao clicar em **Atualizar**, a capacidade é alterada e o espaço passa a exibir o novo valor.

---

## 3. Gestor interdita um espaço

**Tela:** Administração → Espaços → modal "Interditar espaço"

![Interditar espaço](espaco-03-interditar.png)

O gestor aciona a ação de interditar para um espaço **ATIVO**. O modal exibe:

- **Espaço** — dropdown com o espaço selecionado (ex.: `Espaço Cultural · 120 lugares · ATIVO`)
- Aviso: *"Espaços interditados não recebem novos eventos até serem reativados."*

Ao clicar em **Interditar**, o status do espaço passa de **ATIVO** para **INTERDITADO** e ele deixa de aparecer como opção para novos eventos.

---

## 4. Gestor reativa um espaço interditado

**Tela:** Administração → Espaços → modal "Reativar espaço"

![Reativar espaço](espaco-04-reativar.png)

O gestor aciona a ação de reativar para um espaço **INTERDITADO**. O modal exibe:

- **Espaço** — dropdown com o espaço selecionado (ex.: `Espaço Cultural · 120 lugares · INTERDITADO`)
- Aviso: *"Reabilita um espaço interditado para receber novas pautas e reservas."*

Ao clicar em **Reativar**, o status retorna para **ATIVO** e o espaço volta a estar disponível para novos eventos.

---

## Ciclo de vida do espaço

```
ATIVO ──── Interditar ──→ INTERDITADO
  ↑                            │
  └────── Reativar ────────────┘
```

| Status | Recebe novos eventos? |
|---|---|
| **ATIVO** | Sim |
| **INTERDITADO** | Não |
