# Fluxo de Telas — Equipamentos

**Atores:** Gestor (administração) · Produtor (painel do produtor)

---

## 1. Produtor solicita equipamento ao criar evento

**Tela:** Painel do Produtor → Formulário de evento → seção Equipamentos

![Produtor solicita equipamento](equipamentos-01-produtor-solicitar.png)

O produtor preenche as datas do evento (início do período, fim do período, primeira apresentação) e desce até a seção **Equipamentos (opcional)**. Ao clicar em **+ Adicionar equipamento**, uma linha é adicionada com:

- **Dropdown de equipamento** — lista os equipamentos disponíveis no espaço selecionado (ex.: `caixa de som`)
- **Campo QTD.** — quantidade solicitada
- **Indicador de disponibilidade** — exibe em tempo real quantas unidades estão disponíveis (`1 disponíveis`) com ícone verde

O produtor pode adicionar múltiplos equipamentos ou remover uma linha pelo ícone de lixeira.

---

## 2. Gestor visualiza inventário e consulta calendário de alocação

**Tela:** Administração → Equipamentos

![Gestor consulta calendário de alocação](equipamentos-02-gestor-calendario.png)

O gestor seleciona o espaço no dropdown (ex.: `qwdqwd · 200 lugares · ATIVO`) e vê a lista de equipamentos com as colunas:

| Coluna | Descrição |
|---|---|
| **Equipamento** | Nome e ícone do item |
| **Status** | `DISPONÍVEL` (verde) ou `EM MANUTENÇÃO` (vermelho) |
| **Evento Alocado** | Nome do evento que está usando o equipamento |

Ao clicar no ícone de **calendário**, um mini-calendário popup exibe os dias em que o equipamento está alocado (dias destacados em roxo, legenda **Alocado**).

**Ações disponíveis por linha:**

| Ícone | Ação |
|---|---|
| 📅 Calendário | Ver dias alocados |
| 🔧 Chave inglesa | Registrar manutenção |
| ✅ Check | Marcar como disponível |
| 🗑️ Lixeira | Excluir equipamento |

> Registrar manutenção em equipamento alocado dispara notificação automática para o evento (padrão Observer).

---

## 3. Gestor cadastra novo equipamento

**Tela:** Administração → Equipamentos → modal "Novo equipamento"

![Modal novo equipamento](equipamentos-03-gestor-novo-modal.png)

O gestor clica em **+ Novo equipamento** no canto superior direito. O modal exibe:

- **Nome** (obrigatório) — ex.: `Holofote`
- Texto informativo: *"Equipamentos ficam vinculados ao espaço selecionado e iniciam DISPONÍVEIS."*
- Botões: **Cancelar** e **Adquirir**

Ao confirmar, o equipamento é criado com status **DISPONÍVEL** e vinculado ao espaço atualmente selecionado.

---

## 4. Lista de equipamentos atualizada após cadastro

**Tela:** Administração → Equipamentos

![Lista atualizada](equipamentos-04-gestor-lista-atualizada.png)

Após adquirir o novo equipamento, a lista é atualizada automaticamente. O novo item aparece com:

- Status **DISPONÍVEL**
- Coluna "Evento Alocado" exibindo `—` (sem alocação ainda)
- Ações disponíveis: chave inglesa e lixeira (sem calendário e check, pois não está alocado)

Equipamentos já alocados (ex.: `caixa de som`) mantêm o nome do evento na coluna correspondente e exibem o conjunto completo de ações.
